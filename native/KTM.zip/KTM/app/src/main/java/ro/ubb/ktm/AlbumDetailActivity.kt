package ro.ubb.ktm

import android.app.Activity
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.album_detail.*
import ro.ubb.ktm.model.Album
import java.util.jar.Manifest
import kotlin.reflect.typeOf
import android.provider.MediaStore
import androidx.core.app.ComponentActivity
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.net.Uri
import kotlinx.android.synthetic.main.activity_main.*
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.service.*


class AlbumDetailActivity: AppCompatActivity(){
   private lateinit var album : Album
    private  var service = ServiceImplDBVersion(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.album = intent.getSerializableExtra("album") as Album
        setContentView(R.layout.album_detail)

            album_title_labebe.text = (album as Album).name
            val viewAdapter =
                PhotoAdapter(
                    this,
                    album as Album,
                    service
                )
            picture_list.adapter = viewAdapter
        album_description_tview.setText(album.description)

        add_picture_button.setOnClickListener {

            pickImageFromGallery()
        }

        album_options_button.setOnClickListener{

            val intent = Intent(this, AlbumOptionsActivity::class.java)
            intent.putExtra("album",album)

            startActivityForResult(intent, 5);
//            service.deleteAlbum(album)
            finish()
        }




    }
//    init {
//        album = intent.getSerializableExtra("album") as Album
//    }
    private fun pickImageFromGallery() {

        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_PICK_CODE)
    }

    companion object {
        private val IMAGE_PICK_CODE = 1000;
        private val PERMISSION_CODE = 1001;
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(resultCode == Activity.RESULT_OK && requestCode == IMAGE_PICK_CODE){
            var ceva = data?.data

            if (ceva != null){
                var altceva = convertMediaUriToPath(ceva)
                var list = altceva.split("/")
                var name = list[list.size-1]
                println("HERE COMES A NAME")
                println(name)
                val photo = Photo(-1, album.id, "", altceva);
                //  todo add the picture to thedatabase

        }


    }
        if (resultCode == Activity.RESULT_OK && requestCode == 5)
        {
            println("REQ CODE 5 DBG");
            val intent = Intent()
            setResult(Activity.RESULT_OK, intent)
            finish();
        }

        if (resultCode == Activity.RESULT_OK && requestCode == 6)
        {
             album = data?.getSerializableExtra("album") as Album;

            album_description_tview.setText(album.description);

        }

}



    fun convertMediaUriToPath(uri: Uri): String {
        val proj = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = contentResolver.query(uri, proj, null, null, null)
        val column_index = cursor!!.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor.moveToFirst()
        val path = cursor.getString(column_index)
        cursor.close()
        return path
    }

}