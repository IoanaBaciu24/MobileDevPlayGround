package ro.ubb.ktm

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import ro.ubb.ktm.service.AlbumAdapter
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl
import android.content.Intent
import androidx.core.app.ComponentActivity
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import ro.ubb.ktm.service.ServiceImplDBVersion


class MainActivity : AppCompatActivity() {

    private val service = ServiceImplDBVersion(this);
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val viewManager = LinearLayoutManager(this)
        val viewAdapter =
            AlbumAdapter(
                this,
                service
            )

        album_list.adapter = viewAdapter
        create_album.setOnClickListener{
//            println("ALO PRONTO GUCCI CF AICI")
//            Toast.makeText(applicationContext,"this is toast message",Toast.LENGTH_SHORT).show()
//            val toast = Toast.makeText(applicationContext, "Hello Javatpoint", Toast.LENGTH_LONG)
//            toast.show()
//            val myToast = Toast.makeText(applicationContext,"toast message with gravity",Toast.LENGTH_SHORT)
//            myToast.setGravity(Gravity.LEFT,200,200)
//            myToast.show()
            println(service.getAllAlbums().size)

            startActivityForResult(Intent(this, CreateAlbumActivity::class.java), 5);

        }

    }

    override fun onResume() {
//        val viewAdapter =
//            AlbumAdapter(
//                this,
//                service
//            )
        super.onResume()
//        album_list.adapter = viewAdapter
        album_list.adapter?.notifyDataSetChanged();


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode==5)
        {
            if(resultCode== Activity.RESULT_OK)
            {
                println("REQ CODE 6");

                album_list.adapter?.notifyDataSetChanged();
            }
        }

    }


}
