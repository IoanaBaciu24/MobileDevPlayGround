package ro.ubb.ktm

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.album_options.*
import kotlinx.android.synthetic.main.create_album_page.*
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl
import ro.ubb.ktm.service.ServiceImplDBVersion


class AlbumOptionsActivity :  AppCompatActivity(){
    private lateinit var album : Album
    private  var service = ServiceImplDBVersion(this)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.album_options)
        this.album = intent.getSerializableExtra("album") as Album
        delete_album_button.setOnClickListener{
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Are you sure you want to Delete?")
                .setCancelable(false)
                .setPositiveButton("Yes") { dialog, id ->
                    // Delete selected note from database
                    service.deleteAlbum(album)
//                    startActivity(Intent(this, MainActivity::class.java))
                    val intent = Intent()
                    setResult(Activity.RESULT_OK, intent)


                    finish();
                }
                .setNegativeButton("No") { dialog, id ->
                    // Dismiss the dialog
                    dialog.dismiss()
                }
            val alert = builder.create()
            alert.show()

        }

        edit_description_button.setOnClickListener{

            val intent = Intent(this, EditAlbumDescActivity::class.java)
            intent.putExtra("album",album)

            startActivityForResult(intent, 6);
        }
    }


}