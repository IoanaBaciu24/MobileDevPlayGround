package ro.ubb.ktm

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.photo_detail.*
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl

class PhotoDetailActivity : AppCompatActivity(){

    private lateinit var album : Album
    private lateinit var photo: Photo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.photo_detail)

        this.album = intent.getSerializableExtra("album") as Album
        this.photo = intent.getSerializableExtra("photo") as Photo
        var bitmap= BitmapFactory.decodeFile(photo.path_to_picture)

        picture_detail.setImageBitmap(bitmap)
        picture_comment.setText(photo.comment)
//        picture_detail_title.setText(photo.name)
        this.picture_detail_options_button.setOnClickListener{

            val intent = Intent(this, PhotoOptionsActivity::class.java)
            intent.putExtra("album",album)
            intent.putExtra("photo", photo)
            startActivity(intent)
        }

    }




}