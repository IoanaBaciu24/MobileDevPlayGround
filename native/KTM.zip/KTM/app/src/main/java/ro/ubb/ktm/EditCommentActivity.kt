package ro.ubb.ktm

import android.app.AlertDialog
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.edit_album_description_page.*
import kotlinx.android.synthetic.main.edit_comment_page.*
import kotlinx.android.synthetic.main.photo_options.*
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl

class EditCommentActivity : AppCompatActivity(){

    private lateinit var album : Album
    private lateinit var photo: Photo
    private var service = ServiceImpl() as Service


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.edit_comment_page)
        this.album = intent.getSerializableExtra("album") as Album
        this.photo = intent.getSerializableExtra("photo") as Photo
        photo_comment_box.setText(photo.comment)

        edit_photo_comment_button.setOnClickListener{
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Are you sure you want to edit?")
                .setCancelable(false)
                .setPositiveButton("Yes") { dialog, id ->

                    photo.comment = photo_comment_box.text.toString()
                    var new_album = editInAlbum(album, photo)
                    service.replAlbum(new_album)


                }
                .setNegativeButton("No") { dialog, id ->
                    // Dismiss the dialog
                    dialog.dismiss()
                }
            val alert = builder.create()
            alert.show()
        }
    }

    private fun editInAlbum(album: Album, photo: Photo): Album{

//        var idx = 0
//        for( i in 0..album.photos.size){
//
//            if (photo.name == album.photos[i].name)
//            {
//                idx = i
//                break
//            }
//        }
//        album.photos[idx] = photo

        return album
    }
}