package ro.ubb.ktm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.create_album_page.*
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl
import ro.ubb.ktm.service.ServiceImplDBVersion

class CreateAlbumActivity : AppCompatActivity(){

    private val service = ServiceImplDBVersion(this);

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_album_page)
        println("AM AJUNS YAS")

        submit_button_create.setOnClickListener{
            addToService()
            val intent = Intent()
            setResult(Activity.RESULT_OK, intent)
            finish();
        }
    }


    fun addToService(){

        var nameEditText = findViewById(R.id.name_edit_text) as EditText
        var descrEditText = findViewById(R.id.description_edit_text) as EditText

        var album = Album(-1, nameEditText.text.toString(), descrEditText.text.toString())
        service.addAlbum(album);
        println(nameEditText.text)
        println(descrEditText.text)

    }
}