package ro.ubb.ktm

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.album_options.*
import kotlinx.android.synthetic.main.photo_options.*
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.service.Service
import ro.ubb.ktm.service.ServiceImpl

class PhotoOptionsActivity : AppCompatActivity()
{
    private lateinit var album : Album
    private lateinit var photo: Photo
    private lateinit var service: Service

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.photo_options)
        this.album = intent.getSerializableExtra("album") as Album
        this.photo = intent.getSerializableExtra("photo") as Photo
        this.service = ServiceImpl()

        delete_photo_button.setOnClickListener{
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Are you sure you want to Delete?")
                .setCancelable(false)
                .setPositiveButton("Yes") { dialog, id ->
                    // Delete selected note from database

                    var new_album = removeFromAlbum(album, photo)
                    service.replAlbum(album)
                }
                .setNegativeButton("No") { dialog, id ->
                    // Dismiss the dialog
                    dialog.dismiss()
                }
            val alert = builder.create()
            alert.show()

        }

        edit_comment_button.setOnClickListener{

            val intent = Intent(this, EditCommentActivity::class.java)
            intent.putExtra("album",album)
            intent.putExtra("photo", photo)
            startActivity(intent)
        }
    }


    private fun removeFromAlbum(album: Album, photo: Photo): Album{
//
//        var items = album.photos
//        var idx = 0
//        for (i in 0..items.size)
//        {
//            if (items[i].name == photo.name)
//            {
//                idx = i
//                break
//            }
//        }
//
//        items.removeAt(idx)
//        album.photos = items

        return album
    }
}