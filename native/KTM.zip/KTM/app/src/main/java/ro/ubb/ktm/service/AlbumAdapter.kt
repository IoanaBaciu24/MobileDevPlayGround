package ro.ubb.ktm.service

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.ContextMenu
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.album_item.*
import ro.ubb.ktm.AlbumDetailActivity
import ro.ubb.ktm.R
import ro.ubb.ktm.model.Album
import java.io.File
import java.util.zip.Inflater

class AlbumAdapter internal constructor(context: Context?, service: ServiceImplDBVersion): RecyclerView.Adapter<AlbumAdapter.ViewHolder>(){

    private var service: ServiceImplDBVersion
    private var inflater: LayoutInflater
    private var itemClickListener: ItemClickListener? = null
    private val context: Context?




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.album_item, parent, false)
        return ViewHolder(view)    }

    override fun getItemCount(): Int {
        return service.getAllAlbums().size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val values = service.getAllAlbums()
        val item = values[position]
        println(holder.albumName.text)
        holder.albumName.text = item.name
        println(item.name)
//        File image = new File(item.photos[0].path_to_picture)




//        var bImg = BitmapFactory.decodeFile(item.photos[0].path_to_picture)
        var photos = service.getPhotosOfAlbum(item.id)
        if(photos.size >0) {
            var bitmap= BitmapFactory.decodeFile(photos[0].path_to_picture)
//            holder.coverPhoto.setImageResource(item.photos[0].path_to_picture)
            holder.coverPhoto.setImageBitmap(bitmap)
        }
        else{
            holder.coverPhoto.setImageResource(R.drawable.ic_photo_black_24dp)
        }
        with(holder.itemView) {
            tag = item
//            setOnClickListener(onClickListener)
        }

        holder.coverPhoto.setOnClickListener{
            val intent = Intent(this.context, AlbumDetailActivity::class.java)
            intent.putExtra("album",service.getAllAlbums()[position])

//            context?.startActivity(intent)
            (context as Activity).startActivityForResult(intent, 5);

        }
    }
    interface ItemClickListener {
        fun onItemClick(view: View?, position: Int)
    }
    init {
        this.service = service;
        inflater = LayoutInflater.from(context);
        this.context = context;
    }
    fun setClickListener(itemClickListener: ItemClickListener?) {
        this.itemClickListener = itemClickListener
    }
    inner class ViewHolder internal constructor(itemView: View): RecyclerView.ViewHolder(itemView),
            View.OnClickListener{
        var albumName: TextView = itemView.findViewById(R.id.album_name)
        var coverPhoto: ImageView = itemView.findViewById(R.id.cover_photo)

        override fun onClick(v: View?) {
            if (itemClickListener != null)
            {
             itemClickListener!!.onItemClick(v, adapterPosition)}

        }


    }
}