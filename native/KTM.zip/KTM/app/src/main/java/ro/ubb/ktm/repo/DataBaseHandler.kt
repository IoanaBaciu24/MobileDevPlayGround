package ro.ubb.ktm.repo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ro.ubb.ktm.model.Album
import ro.ubb.ktm.model.Photo
import ro.ubb.ktm.repo.AlbumContract.AbumEntry.ALBUM_TABLE_NAME
import ro.ubb.ktm.repo.AlbumContract.AbumEntry.COL_ALBUM_DESCRIPTION
import ro.ubb.ktm.repo.AlbumContract.AbumEntry.COL_ALBUM_ID
import ro.ubb.ktm.repo.AlbumContract.AbumEntry.COL_ALBUM_NAME
import ro.ubb.ktm.repo.AlbumContract.DATABASE_NAME
import ro.ubb.ktm.repo.AlbumContract.DATABASE_VERSION
import ro.ubb.ktm.repo.AlbumContract.PhotoEntry.COL_PICTURE_COMMENT
import ro.ubb.ktm.repo.AlbumContract.PhotoEntry.COL_PICTURE_ID
import ro.ubb.ktm.repo.AlbumContract.PhotoEntry.COL_PICTURE_PATH
import ro.ubb.ktm.repo.AlbumContract.PhotoEntry.PHOTO_TABLE_NAME


class DataBaseHandler(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null,
    DATABASE_VERSION)
{
    override fun onCreate(db: SQLiteDatabase?) {
        val create_albums = "CREATE TABLE "+ ALBUM_TABLE_NAME + " (" + COL_ALBUM_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ALBUM_NAME + " VARCHAR(50), " +
                COL_ALBUM_DESCRIPTION + " VARCHAR(500))";

        var create_photo = "CREATE TABLE " + PHOTO_TABLE_NAME + " (" +
                COL_PICTURE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                COL_PICTURE_COMMENT + " VARCHAR(500), " +
                COL_PICTURE_PATH + " VARCHAR(500), " +
                COL_ALBUM_ID + " INTEGER, "+
                "FOREIGN KEY(" + COL_ALBUM_ID + ") REFERENCES " + ALBUM_TABLE_NAME + "(" + COL_ALBUM_ID + ") ON DELETE CASCADE)";

        println(create_albums)
        println(create_photo)
        db?.execSQL(create_albums);
        db?.execSQL(create_photo);

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    fun insertAlbum(album: Album)
    {
        val db = this.writableDatabase
        var cv = ContentValues();

        cv.put(COL_ALBUM_NAME, album.name);
        cv.put(COL_ALBUM_DESCRIPTION, album.description)

        val result = db.insert(ALBUM_TABLE_NAME, null, cv);
        println(result);

    }

    fun insertPictureToAlbum(pic: Photo)
    {
        val db = this.writableDatabase
        val cv = ContentValues();

        cv.put(COL_PICTURE_COMMENT, pic.comment);
        cv.put(COL_PICTURE_PATH, pic.path_to_picture)
        cv.put(COL_ALBUM_ID, pic.albumId)

        val result = db.insert(PHOTO_TABLE_NAME, null, cv);
        println(result);
    }

    fun queryAllAlbums(): Cursor
    {
        val db = this.writableDatabase
        return db.rawQuery("select * from ${ALBUM_TABLE_NAME}", null)
    }

    fun queryPhotosOfAlbum(albumId: Int): Cursor
    {
        val db = this.writableDatabase
        return db.rawQuery("select * from ${PHOTO_TABLE_NAME} where " + COL_ALBUM_ID + "= " + albumId.toString(), null )

    }


    fun deleteAlbum(albumId: Int)
    {
        val db = this.writableDatabase
        var a = arrayOf(albumId.toString())

        val delete = db.delete(ALBUM_TABLE_NAME, COL_ALBUM_ID + "=?", a)
        println(delete)
        println("DELETED ALBUM")
    }

    fun updateAlbum(album: Album) {

        val db = this.writableDatabase
        var a = arrayOf(album.id.toString())
        val values = ContentValues()
        values.put(COL_ALBUM_DESCRIPTION, album.description)
        values.put(COL_ALBUM_NAME, album.name)
        val update = db.update(ALBUM_TABLE_NAME, values, COL_ALBUM_ID + "=?", a)
        println(update)
    }

    fun deletePicture(picId: Int)
    {
        val db = this.writableDatabase
        var a = arrayOf(picId.toString())

        val delete = db.delete(PHOTO_TABLE_NAME, COL_ALBUM_ID + "=?", a)
        println(delete)
    }

    fun updatePicture(pic: Photo)
    {
        val db = this.writableDatabase
        var a = arrayOf(pic.id.toString())
        val values = ContentValues()
        values.put(COL_PICTURE_PATH, pic.path_to_picture)
        values.put(COL_PICTURE_COMMENT, pic.comment)
        values.put(COL_ALBUM_ID, pic.albumId)
        val update = db.update(ALBUM_TABLE_NAME, values, COL_PICTURE_ID + "=?", a)
        println(update)

    }
}




